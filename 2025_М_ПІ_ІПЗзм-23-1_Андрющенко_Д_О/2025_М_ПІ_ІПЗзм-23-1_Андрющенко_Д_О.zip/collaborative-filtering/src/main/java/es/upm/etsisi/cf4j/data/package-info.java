/** This package contains data classes of CF4J. */
package es.upm.etsisi.cf4j.data;
