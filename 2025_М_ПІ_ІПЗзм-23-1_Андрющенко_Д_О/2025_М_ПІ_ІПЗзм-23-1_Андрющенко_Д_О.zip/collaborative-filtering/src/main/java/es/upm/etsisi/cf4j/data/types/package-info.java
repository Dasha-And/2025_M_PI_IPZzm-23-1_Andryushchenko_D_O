/** This package contains types classes used by data objects of CF4J. */
package es.upm.etsisi.cf4j.data.types;
