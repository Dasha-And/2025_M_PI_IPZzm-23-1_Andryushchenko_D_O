/** This package contains examples of CF4J usage. */
package es.upm.etsisi.cf4j.examples;
