/** This package contains examples showing how to plot with CF4J */
package es.upm.etsisi.cf4j.examples.plot;
