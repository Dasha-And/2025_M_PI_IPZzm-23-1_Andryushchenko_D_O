package es.upm.etsisi.cf4j.examples.recommender.custom;

import es.upm.etsisi.cf4j.data.BenchmarkDataModels;
import es.upm.etsisi.cf4j.data.DataModel;
import es.upm.etsisi.cf4j.qualityMeasure.QualityMeasure;
import es.upm.etsisi.cf4j.qualityMeasure.prediction.MAE;
import es.upm.etsisi.cf4j.qualityMeasure.prediction.RMSE;
import es.upm.etsisi.cf4j.recommender.Recommender;
import es.upm.etsisi.cf4j.recommender.knn.ItemKNN;
import es.upm.etsisi.cf4j.recommender.knn.UserKNN;
import es.upm.etsisi.cf4j.recommender.knn.contentFilteringSimilarityMetric.AdjustedCosine;
import es.upm.etsisi.cf4j.recommender.knn.contentFilteringSimilarityMetric.ContentFilteringSimilarityMetric;
import es.upm.etsisi.cf4j.recommender.knn.itemSimilarityMetric.ItemSimilarityMetric;
import es.upm.etsisi.cf4j.recommender.knn.itemSimilarityMetric.JMSD;
import es.upm.etsisi.cf4j.recommender.knn.itemSimilarityMetric.Jaccard;
import es.upm.etsisi.cf4j.recommender.knn.userSimilarityMetric.SpearmanRank;
import es.upm.etsisi.cf4j.recommender.knn.userSimilarityMetric.UserSimilarityMetric;
import es.upm.etsisi.cf4j.recommender.matrixFactorization.PMF;
import es.upm.etsisi.cf4j.recommender.neural.NeuMF;
import es.upm.etsisi.cf4j.util.Maths;
import es.upm.etsisi.cf4j.util.plot.LinePlot;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GeneralComparison {
    private static final int[] NUM_FACTORS = Maths.range(10, 50, 10);

    private static final int NUM_ITERS = 50;

    private static final long RANDOM_SEED = 43;
    private static final UserKNN.AggregationApproach AGGREGATION_APPROACH =
        UserKNN.AggregationApproach.DEVIATION_FROM_MEAN;

    private static final ItemKNN.AggregationApproach AGGREGATION_APPROACH_1 =
        ItemKNN.AggregationApproach.MEAN;
    public static void main(String[] args) throws IOException {
        DataModel datamodel = BenchmarkDataModels.MovieLens100K();

        LinePlot rmsePlot = new LinePlot(NUM_FACTORS, "Number of N/LF", "RMSE");
        LinePlot maePlot = new LinePlot(NUM_FACTORS, "Number of N/LF", "MAE");

        List<UserSimilarityMetric> metrics = new ArrayList<>();
        metrics.add(new SpearmanRank());

        for (UserSimilarityMetric metric : metrics) {
            String metricName = metric.getClass().getSimpleName();

            if (metricName.equals("SpearmanRank")) {
                metricName = "User-KNN";
            }

            maePlot.addSeries(metricName);
            rmsePlot.addSeries(metricName);

            for (int k : NUM_FACTORS) {
                Recommender knn = new UserKNN(datamodel, k, metric, AGGREGATION_APPROACH);
                knn.fit();

                QualityMeasure mae = new MAE(knn);
                double maeScore = mae.getScore();
                maePlot.setValue(metricName, k, maeScore);

                QualityMeasure rmse = new RMSE(knn);
                double rmseScore = rmse.getScore();
                rmsePlot.setValue(metricName, k, rmseScore);
            }
        }

        ArrayList<ItemSimilarityMetric> metricsItem = new ArrayList<>();
        metricsItem.add(new Jaccard());

        for (ItemSimilarityMetric metric : metricsItem) {
            String metricName = metric.getClass().getSimpleName();

            if (metricName.equals("Jaccard")) {
                metricName = "Item-KNN";
            }

            maePlot.addSeries(metricName);
            rmsePlot.addSeries(metricName);

            for (int k : NUM_FACTORS) {
                Recommender knn = new ItemKNN(datamodel, k, metric, AGGREGATION_APPROACH_1);
                knn.fit();

                QualityMeasure mae = new MAE(knn);
                double maeScore = mae.getScore();
                maePlot.setValue(metricName, k, maeScore);

                QualityMeasure msle = new RMSE(knn);
                double msleScore = msle.getScore();
                rmsePlot.setValue(metricName, k, msleScore);
            }
        }

        maePlot.addSeries("PMF");
        maePlot.addSeries("NCF");
        rmsePlot.addSeries("PMF");
        rmsePlot.addSeries("NCF");

        for (int factors : NUM_FACTORS) {
            Recommender pmf = new PMF(datamodel, factors, NUM_ITERS, RANDOM_SEED);
            pmf.fit();

            QualityMeasure maePmf = new MAE(pmf);
            double maePmfScore = maePmf.getScore();
            maePlot.setValue("PMF", factors, maePmfScore);

            QualityMeasure rmsePmf = new RMSE(pmf);
            double rmsePmfScore = rmsePmf.getScore();
            rmsePlot.setValue("PMF", factors, rmsePmfScore);
        }

        for (int factors : NUM_FACTORS) {
            Recommender ncf = new NeuMF(datamodel, factors, factors, 3, 0.01);
            ncf.fit();

            QualityMeasure maeNcf = new MAE(ncf);
            double maeNcfScore = maeNcf.getScore();
            maePlot.setValue("NCF", factors, maeNcfScore);

            QualityMeasure rmseNcf = new RMSE(ncf);
            double rmseNcfScore = rmseNcf.getScore();
            rmsePlot.setValue("NCF", factors, rmseNcfScore);
        }

//        List<ContentFilteringSimilarityMetric> metricsContent = new ArrayList<>();
//        metricsContent.add(new AdjustedCosine());

//        for (ContentFilteringSimilarityMetric metric : metricsContent) {
//            String metricName = metric.getClass().getSimpleName();
//
//            if (metricName.equals("AdjustedCosine")) {
//                metricName = "Content-filtering";
//            }
//
//            maePlot.addSeries(metricName);
//            rmsePlot.addSeries(metricName);
//
//            for (int k : NUM_FACTORS) {
//                Recommender knn = new ItemKNN(datamodel, k, metric, AGGREGATION_APPROACH_1);
//                knn.fit();
//
//                QualityMeasure mae = new MAE(knn);
//                double maeScore = mae.getScore();
//                maePlot.setValue(metricName, k, maeScore);
//
//                QualityMeasure rmse = new RMSE(knn);
//                double rmseScore = rmse.getScore();
//                rmsePlot.setValue(metricName, k, rmseScore);
//            }
//        }

        maePlot.draw();
        maePlot.printData("0", "0.0000");
        rmsePlot.draw();
        rmsePlot.printData("0", "0.0000");
    }
}
