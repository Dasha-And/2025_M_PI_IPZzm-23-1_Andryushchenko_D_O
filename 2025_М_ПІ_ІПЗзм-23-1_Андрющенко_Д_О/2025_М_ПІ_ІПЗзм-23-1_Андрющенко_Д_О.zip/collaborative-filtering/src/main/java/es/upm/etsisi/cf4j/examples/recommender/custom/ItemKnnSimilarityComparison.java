package es.upm.etsisi.cf4j.examples.recommender.custom;

import es.upm.etsisi.cf4j.data.BenchmarkDataModels;
import es.upm.etsisi.cf4j.data.DataModel;
import es.upm.etsisi.cf4j.qualityMeasure.QualityMeasure;
import es.upm.etsisi.cf4j.qualityMeasure.prediction.MAE;
import es.upm.etsisi.cf4j.qualityMeasure.prediction.RMSE;
import es.upm.etsisi.cf4j.qualityMeasure.recommendation.NDCG;
import es.upm.etsisi.cf4j.recommender.Recommender;
import es.upm.etsisi.cf4j.recommender.knn.ItemKNN;
import es.upm.etsisi.cf4j.recommender.knn.itemSimilarityMetric.AdjustedCosine;
import es.upm.etsisi.cf4j.recommender.knn.itemSimilarityMetric.Correlation;
import es.upm.etsisi.cf4j.recommender.knn.itemSimilarityMetric.ItemSimilarityMetric;
import es.upm.etsisi.cf4j.recommender.knn.itemSimilarityMetric.Jaccard;
import es.upm.etsisi.cf4j.recommender.knn.itemSimilarityMetric.SpearmanRank;
import es.upm.etsisi.cf4j.util.Maths;
import es.upm.etsisi.cf4j.util.plot.LinePlot;
import java.io.IOException;
import java.util.ArrayList;

public class ItemKnnSimilarityComparison {

    private static final int[] NUM_NEIGHBORS = Maths.range(10, 50, 10);

    private static final ItemKNN.AggregationApproach AGGREGATION_APPROACH =
        ItemKNN.AggregationApproach.MEAN;

    public static void main(String[] args) throws IOException {

        // DataModel load
        DataModel datamodel = BenchmarkDataModels.MovieLens100K();

        // To store results
        LinePlot maePlot = new LinePlot(NUM_NEIGHBORS, "Number of neighbors (Item-KNN model)", "MAE");
        LinePlot mslePlot = new LinePlot(NUM_NEIGHBORS, "Number of neighbors (Item-KNN model)", "RMSE");

        // Create similarity metrics
        ArrayList<ItemSimilarityMetric> metrics = new ArrayList<>();
        metrics.add(new AdjustedCosine());
        metrics.add(new Correlation());
        metrics.add(new Jaccard());
        metrics.add(new SpearmanRank());

        // Evaluate ItemKNN recommender for each similarity metric
        for (ItemSimilarityMetric metric : metrics) {
            String metricName = metric.getClass().getSimpleName();

            maePlot.addSeries(metricName);
            mslePlot.addSeries(metricName);

            for (int k : NUM_NEIGHBORS) {
                Recommender knn = new ItemKNN(datamodel, k, metric, AGGREGATION_APPROACH);
                knn.fit();

                QualityMeasure mae = new MAE(knn);
                double maeScore = mae.getScore();
                maePlot.setValue(metricName, k, maeScore);

                QualityMeasure msle = new RMSE(knn);
                double msleScore = msle.getScore();
                mslePlot.setValue(metricName, k, msleScore);

            }
        }

        // Print results
        maePlot.draw();
        mslePlot.draw();
        mslePlot.printData("0", "0.0000");
        maePlot.printData("0", "0.0000");
    }
}
