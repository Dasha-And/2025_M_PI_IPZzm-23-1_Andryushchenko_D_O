package es.upm.etsisi.cf4j.examples.recommender.custom;

import es.upm.etsisi.cf4j.data.BenchmarkDataModels;
import es.upm.etsisi.cf4j.data.DataModel;
import es.upm.etsisi.cf4j.qualityMeasure.QualityMeasure;
import es.upm.etsisi.cf4j.qualityMeasure.prediction.MAE;
import es.upm.etsisi.cf4j.qualityMeasure.prediction.RMSE;
import es.upm.etsisi.cf4j.recommender.Recommender;
import es.upm.etsisi.cf4j.recommender.knn.UserKNN;
import es.upm.etsisi.cf4j.recommender.knn.userSimilarityMetric.AdjustedCosine;
import es.upm.etsisi.cf4j.recommender.knn.userSimilarityMetric.Correlation;
import es.upm.etsisi.cf4j.recommender.knn.userSimilarityMetric.Jaccard;
import es.upm.etsisi.cf4j.recommender.knn.userSimilarityMetric.SpearmanRank;
import es.upm.etsisi.cf4j.recommender.knn.userSimilarityMetric.UserSimilarityMetric;
import es.upm.etsisi.cf4j.util.Maths;
import es.upm.etsisi.cf4j.util.plot.LinePlot;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class UserKnnSimilarityComparison {
    private static final int[] numNeighbors = Maths.range(10, 50, 10);

    private static final UserKNN.AggregationApproach AGGREGATION_APPROACH =
        UserKNN.AggregationApproach.DEVIATION_FROM_MEAN;

    public static void main(String[] args) throws IOException {

        // DataModel load
        DataModel datamodel = BenchmarkDataModels.MovieLens100K();

        // To store results
        LinePlot maePlot = new LinePlot(numNeighbors, "Number of neighbors (User-KNN model)", "MAE");
        LinePlot rmsePlot = new LinePlot(numNeighbors, "Number of neighbors (User-KNN model)", "RMSE");

        // Create similarity metrics
        List<UserSimilarityMetric> metrics = new ArrayList<>();
        metrics.add(new AdjustedCosine());
        metrics.add(new Correlation());
        metrics.add(new Jaccard());
        metrics.add(new SpearmanRank());

        // Evaluate UserKNN recommender
        for (UserSimilarityMetric metric : metrics) {
            String metricName = metric.getClass().getSimpleName();

            maePlot.addSeries(metricName);
            rmsePlot.addSeries(metricName);

            for (int k : numNeighbors) {
                Recommender knn = new UserKNN(datamodel, k, metric, AGGREGATION_APPROACH);
                knn.fit();

                QualityMeasure mae = new MAE(knn);
                double maeScore = mae.getScore();
                maePlot.setValue(metricName, k, maeScore);

                QualityMeasure rmse = new RMSE(knn);
                double rmseScore = rmse.getScore();
                rmsePlot.setValue(metricName, k, rmseScore);
            }
        }

        // Print results
        maePlot.draw();
        rmsePlot.draw();
        maePlot.printData("0", "0.0000");
        rmsePlot.printData("0", "0.0000");
    }
}
