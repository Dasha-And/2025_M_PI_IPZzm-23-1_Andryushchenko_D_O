/** This package contains examples showing how to compare different Recommenders with CF4J. */
package es.upm.etsisi.cf4j.examples.recommender;
