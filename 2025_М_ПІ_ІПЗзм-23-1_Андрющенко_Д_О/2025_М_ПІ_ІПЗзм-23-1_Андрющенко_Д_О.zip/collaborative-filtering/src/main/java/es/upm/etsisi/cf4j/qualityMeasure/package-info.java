/**
 * Contains the implementation of different quality measures for collaborative filtering based
 * recommender systems.
 */
package es.upm.etsisi.cf4j.qualityMeasure;
