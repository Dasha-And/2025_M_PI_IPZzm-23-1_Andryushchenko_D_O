/** Contains the implementation of different quality measures oriented to predictions. */
package es.upm.etsisi.cf4j.qualityMeasure.prediction;
