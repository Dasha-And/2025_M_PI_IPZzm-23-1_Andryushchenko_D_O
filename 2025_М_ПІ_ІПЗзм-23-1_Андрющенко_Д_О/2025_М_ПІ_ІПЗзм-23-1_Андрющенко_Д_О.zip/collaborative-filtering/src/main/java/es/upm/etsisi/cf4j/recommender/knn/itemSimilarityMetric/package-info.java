/**
 * This package contains different implementations of item-to-item similarity metrics used in the
 * item-to-item knn based collaborative filtering algorithm.
 */
package es.upm.etsisi.cf4j.recommender.knn.itemSimilarityMetric;
