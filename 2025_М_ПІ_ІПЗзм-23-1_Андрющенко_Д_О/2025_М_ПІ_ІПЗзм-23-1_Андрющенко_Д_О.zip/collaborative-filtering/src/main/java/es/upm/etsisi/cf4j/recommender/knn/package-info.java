/**
 * This package contains the implementation of different knn based collaborative filtering
 * recommenders.
 */
package es.upm.etsisi.cf4j.recommender.knn;
