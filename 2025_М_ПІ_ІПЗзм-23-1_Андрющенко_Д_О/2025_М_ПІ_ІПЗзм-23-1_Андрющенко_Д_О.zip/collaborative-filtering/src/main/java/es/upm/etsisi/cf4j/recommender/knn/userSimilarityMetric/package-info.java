/**
 * This package contains different implementations of user-to-user similarity metric used in the
 * user-to-user knn based collaborative filtering algorithm.
 */
package es.upm.etsisi.cf4j.recommender.knn.userSimilarityMetric;
