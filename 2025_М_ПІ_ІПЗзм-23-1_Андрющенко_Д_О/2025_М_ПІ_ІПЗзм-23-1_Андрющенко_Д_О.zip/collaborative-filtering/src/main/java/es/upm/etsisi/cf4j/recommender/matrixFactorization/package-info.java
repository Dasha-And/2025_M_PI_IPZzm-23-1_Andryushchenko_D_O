/**
 * This package contains the implementation of different matrix factorization based collaborative
 * filtering recommenders.
 */
package es.upm.etsisi.cf4j.recommender.matrixFactorization;
