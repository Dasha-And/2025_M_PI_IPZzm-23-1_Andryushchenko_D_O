/**
 * This package contains the implementation of different neural networks based collaborative
 * filtering recommenders.
 */
package es.upm.etsisi.cf4j.recommender.neural;
