/**
 * This package contains the implementation of different collaborative filtering based recommenders.
 */
package es.upm.etsisi.cf4j.recommender;
