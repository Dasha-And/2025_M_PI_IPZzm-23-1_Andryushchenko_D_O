/** This package contains different utilities used by the CF4J. */
package es.upm.etsisi.cf4j.util;
