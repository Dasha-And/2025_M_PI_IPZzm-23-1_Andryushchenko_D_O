/**
 * This package includes plotting utils designed to analyze data of results obtained as consequence
 * of collaborative filtering research.
 */
package es.upm.etsisi.cf4j.util.plot;
