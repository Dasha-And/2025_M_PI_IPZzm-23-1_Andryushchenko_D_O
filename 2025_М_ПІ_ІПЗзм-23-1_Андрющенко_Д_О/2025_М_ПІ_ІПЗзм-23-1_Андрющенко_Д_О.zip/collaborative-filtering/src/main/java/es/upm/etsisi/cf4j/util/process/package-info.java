/** This package includes processing utils designed to parallelize fitting processes. */
package es.upm.etsisi.cf4j.util.process;
